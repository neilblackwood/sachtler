<?php

class JigoShopML {

    function __construct( ) {
        add_action( 'plugins_loaded', array( $this, 'init' ), 2 );
    }
    
    function init( ) {
        if ( !defined( 'ICL_SITEPRESS_VERSION' ) || ICL_PLUGIN_INACTIVE ) {
            if ( !function_exists( 'is_multisite' ) || !is_multisite() ) {
                add_action( 'admin_notices', array( $this, 'no_wpml_warning' ) );
            }
            
            return false;
        } else if ( version_compare( ICL_SITEPRESS_VERSION, '2.0.5', '<' ) ) {
            add_action( 'admin_notices', array( $this, 'old_wpml_warning' ) );
            
            return false;
        } else if ( !class_exists( 'jigoshop' ) ) {
            add_action( 'admin_notices', array( $this, 'no_jigoshop' ) );
            
            return false;
        }
        
        add_filter( 'icl_ls_languages', array( $this, 'language_selector' ) );
        add_filter( 'jigoshop_params', array( $this, 'params' ) );
        add_filter( 'jigoshop_get_cart_page_id', array( $this, 'get_cart_url' ) );
        add_filter( 'jigoshop_get_checkout_url', array( $this, 'get_checkout_url' ) );
        add_filter( 'jigoshop_get_cart_url', array( $this, 'get_cart_url' ) );
        add_filter( 'jigoshop_get_return_url', array( $this, 'get_return_url' ) );
        add_filter( 'jigoshop_get_cancel_order', array( $this, 'get_cancel_order_url' ) );
        add_filter( 'jigoshop_get_myaccount_page_id', array( $this, 'get_myaccount_page_id' ) );
        add_filter( 'jigoshop_get_edit_address_page_id', array( $this, 'get_edit_address_page_id' ) );
        add_filter( 'jigoshop_get_view_order_page_id', array( $this, 'get_view_order_page_id' ) );
        add_filter( 'jigoshop_get_change_password_page_id', array( $this, 'get_change_password_page_id' ) );
        add_filter( 'jigoshop_get_checkout_redirect_page_id', array( $this, 'get_thanks_page_id' ) );
        add_filter( 'jigoshop_get_shop_page_id', array( $this, 'shop_page_id'  ) );
        add_filter( 'jigoshop_product_url_display_in_cart', array( $this, 'product_url_display_in_cart' ), 11, 2 );
        add_filter( 'jigoshop_get_order', array( $this, 'order_language' ), 12, 2 );
        add_filter( 'jigoshop_session_location_filter', array( $this, 'session_location' ) );
        add_filter( 'jigoshop_get_checkout_payment_url', array( $this, 'get_checkout_payment_url' ) );
        add_filter( 'jigoshop_is_ajax_payment_successful', array( $this, 'is_ajax_payment_successful' ) );
        add_filter( 'jigoshop_product_id_add_to_cart_filter', array( $this, 'product_id_add_to_cart' ) );
        add_filter( 'jigoshop_cart_product_title', array( $this, 'cart_product_title' ), 20, 2 );
		add_filter( 'jigoshop_available_payment_gateways', array( $this, 'translate_payment_gateways' ) );
        
        if ( is_admin() ) {
            add_action( 'admin_footer', array( $this, 'documentation_links'  ) );
            add_action( 'admin_init', array( $this, 'make_new_attributes_translatable' ) );
            add_action( 'admin_notices', array( $this, 'admin_notice_after_install' ) );
        }
        
        if ( isset( $_GET[ 'jsml_action' ] ) && $_GET[ 'jsml_action' ] = 'dismiss' ) {
            update_option( 'wpml_dismiss_doc_main', 'yes' );
        }
        
        register_deactivation_hook( __FILE__, array( $this, 'jsml_deactivate' ) );
		
		if (defined('DOING_AJAX') && DOING_AJAX){
			do_action('icl_localize_on_ajax');
		}
		
		add_action( 'icl_localize_on_ajax', array( $this, 'localize_on_ajax') );
    }
    
    /**
     * Admin notice after plugin install.
     */
    function admin_notice_after_install( ) {
        if ( get_option( 'wpml_dismiss_doc_main' ) != 'yes' ) {
            $url = $_SERVER[ 'REQUEST_URI' ];
            $pos = strpos( $url, '?' );
            
            if ( $pos !== false ) {
                $url .= '&jsml_action=dismiss';
            } else {
                $url .= '?jsml_action=dismiss';
            }
?>
            <div id="message" class="updated message fade" style="clear:both;margin-top:5px;"><p>
                <?php
            _e( 'Would you like to see a quick overview?', 'sitepress' );
?>
                </p>
                <p>
                <a class="button-primary" href="http://wpml.org/documentation/related-projects/jigoshop-multilingual/" target="_blank">Learn how to turn your e-commerce site multilingual</a>
                <a class="button-secondary" href="<?php
            echo $url;
?>">Dismiss</a>
                </p>
            </div>
    <?php
        }
    }
    
    /**
     * Outputs documentation links.
     */
    function documentation_links( ) {
        global $post, $pagenow;
        
        $get_post_type = get_post_type( @$post->ID );
        
        if ( $get_post_type == 'product' && $pagenow == 'edit.php' ) {
            $prot_link = '<span class="button" style="padding:4px;margin-top:10px;"><img align="baseline" src="' . ICL_PLUGIN_URL . '/res/img/icon16.png" width="16" height="16" style="margin-bottom:-4px" /> <a href="http://wpml.org/documentation/related-projects/jigoshop-multilingual/#translating_products" target="_blank">' . __( 'How to translate products', 'sitepress' ) . '<\/a>' . '<\/span>'?>
                <script type="text/javascript">
                    jQuery(".subsubsub").append('<?php
            echo $prot_link;
?>');
                </script>
        <?php
        }
        
        if ( isset( $_GET[ 'taxonomy' ] ) ) {
            $pos = strpos( $_GET[ 'taxonomy' ], 'pa_' );
            
            if ( $pos !== false && $pagenow == 'edit-tags.php' ) {
                $prot_link = '<span class="button" style="padding:4px;margin-top:0px; float: left;"><img align="baseline" src="' . ICL_PLUGIN_URL . '/res/img/icon16.png" width="16" height="16" style="margin-bottom:-4px" /> <a href="http://wpml.org/documentation/related-projects/jigoshop-multilingual/#translating_attributes" target="_blank" style="text-decoration: none;">' . __( 'How to translate attributes', 'sitepress' ) . '<\/a>' . '<\/span><br \/><br \/>'?>
                        <script type="text/javascript">
                            jQuery("table.widefat").before('<?php
                echo $prot_link;
?>');
                        </script>
                <?php
            }
        }
        
        if ( isset( $_GET[ 'taxonomy' ] ) && $_GET[ 'taxonomy' ] == 'product_cat' ) {
            $prot_link = '<span class="button" style="padding:4px;margin-top:0px; float: left;"><img align="baseline" src="' . ICL_PLUGIN_URL . '/res/img/icon16.png" width="16" height="16" style="margin-bottom:-4px" /> <a href="http://wpml.org/documentation/related-projects/jigoshop-multilingual/#translating_product_categories" target="_blank" style="text-decoration: none;">' . __( 'How to translate product categories', 'sitepress' ) . '<\/a>' . '<\/span><br \/><br \/>'?>
                        <script type="text/javascript">
                            jQuery("table.widefat").before('<?php
            echo $prot_link;
?>');
                        </script>
                <?php
        }
    }
    
    /**
     * JigoShop Multilingual deactivation hook.
     */
    function jsml_deactivate( ) {
        delete_option( 'wpml_dismiss_doc_main' );
    }
    
    /**
     * Makes all new attributes translatable.
     */
    function make_new_attributes_translatable( ) {
        if ( isset( $_GET[ 'page' ] ) && $_GET[ 'page' ] == 'jigoshop_attributes' ) {
            $wpml_settings = get_option( 'icl_sitepress_settings' );
            
            $get_all_taxonomies = get_taxonomies( @$args[ 'name' ] );
            
            foreach ( $get_all_taxonomies as $tax_key => $taxonomy ) {
                $pos = strpos( $taxonomy, 'pa_' );
                
                // get only product attribute taxonomy name
                if ( $pos !== false ) {
                    if ( $wpml_settings[ 'taxonomies_sync_option' ] ) {
                        foreach ( $wpml_settings[ 'taxonomies_sync_option' ] as $wpml_tax_key => $tax ) {
                            // set it as translatable
                            $wpml_settings[ 'taxonomies_sync_option' ][ $taxonomy ] = 1;
                        }
                    } else {
                        $wpml_settings[ 'taxonomies_sync_option' ][ $taxonomy ] = 1;
                    }
                }
            }
            
            update_option( 'icl_sitepress_settings', $wpml_settings );
        }
    }
    
    /**
     * Adds admin notice.
     */
    function no_wpml_warning( ) {
?>
        <div class="message error"><p><?php
        printf( __( 'JigoShop Multilingual is enabled but not effective. It requires <a href="%s">WPML</a> in order to work.', 'plugin jigoshop' ), 'http://wpml.org/' );
?></p></div>
    <?php
    }
    
    /**
     * Adds admin notice.
     */
    function old_wpml_warning( ) {
?>
        <div class="message error"><p><?php
        printf( __( 'JigoShop Multilingual is enabled but not effective. It is not compatible with  <a href="%s">WPML</a> versions prior 2.0.5.', 'plugin jigoshop' ), 'http://wpml.org/' );
?></p></div>
    <?php
    }
    
    /**
     * Adds admin notice.
     */
    function no_jigoshop( ) {
?>
        <div class="message error"><p><?php
        printf( __( 'JigoShop Multilingual is enabled but not effective. It requires <a href="%s">JigoShop</a> in order to work.', 'plugin jigoshop' ), 'http://jigoshop.com/' );
?></p></div>
    <?php
    }
    
    /**
     * Filters JigoShop product link in the cart page.
     * 
     * @global type $sitepress
     * @param type $url
     * @param type $product_id
     * @return type 
     */
    function product_url_display_in_cart( $url, $product_id ) {
        global $sitepress;
        
        $product_id = icl_object_id( $product_id, 'product', true );
        
        return $sitepress->convert_url( get_permalink( $product_id ) );
    }
    
    /**
     * Filters JigoShop product ID when adding the product to the cart.
     * 
     * @param type $product_id
     * @return type 
     */
    function product_id_add_to_cart( $product_id ) {
        $product_id = icl_object_id( $product_id, 'product', true, icl_get_default_language() );
        
        return $product_id;
    }
    
    /**
     * Synchronizes post meta 'stock' and 'stock_status' betweeen translated posts.
     * 
     * @global type $sitepress
     * @param type $meta_id
     * @param type $object_id
     * @param type $meta_key
     * @param type $_meta_value 
     */
    function updated_post_meta_hook( $meta_id, $object_id, $meta_key, $_meta_value ) {
        global $sitepress;
        $update_meta_keys = array(
             'stock',
            'stock_status' 
        );
        
        if ( in_array( $meta_key, $update_meta_keys ) ) {
            $translations = $sitepress->get_element_translations( $object_id, 'product' );
            
            foreach ( $translations as $t ) {
                if ( !$t->original ) {
                    if ( $meta_key == 'stock' ) {
                        update_post_meta( $t->translation_id, 'stock', $_meta_value );
                    } else if ( $meta_key = 'stock_status' ) {
                        update_post_meta( $t->translation_id, 'stock_status', $_meta_value );
                    }
                }
            }
        }
    }
    
    /**
     * Filters JigoShop successful page URL after the checkout process.
     * 
     * @global type $post
     * @global type $sitepress
     * @return type 
     */
    function is_ajax_payment_successful( $result ) {
        global $sitepress;
        
        if ( $sitepress->get_current_language() !== $sitepress->get_default_language() ) {
            $lang = $_SESSION[ 'wpml_globalcart_language' ];
            
            $sitepress->switch_lang( $lang );
            
        }
        
        return $result;
    }
    
    /**
     * Filters JigoShop cancel order link.
     * 
     * @global type $sitepress
     * @param type $link
     * @return type 
     */
    function get_cancel_order_url( $link ) {
        global $sitepress;
        return $sitepress->convert_url( $link );
    }
    
    /**
     * Filters JigoShop return URL after payment.
     * 
     * @global type $sitepress
     * @param type $link
     * @return type 
     */
    function get_return_url( $link ) {
        global $sitepress;
        return $sitepress->convert_url( $link );
    }
    
    /**
     * Filters JigoShop redirect URL.
     * 
     * @global type $sitepress
     * @param type $link
     * @return type 
     */
    function session_location( $link ) {
        global $sitepress;
        return $sitepress->convert_url( $link );
    }
    
    /**
     * Filters JigoShop payment successful URL.
     * 
     * @global type $sitepress
     * @param type $result
     * @return type 
     */
    function get_payment_successful_url( $link ) {
        global $sitepress;
        return $sitepress->convert_url( $link );
    }
    
    /**
     * Filters JigoShop shop URL.
     * 
     */
    function shop_page_id( ) {
        return get_permalink( icl_object_id( get_option( 'jigoshop_shop_page_id' ), 'page', true ) );
    }
    
    /**
     * Filters JigoShop thanks page ID.
     * 
     */
    function get_thanks_page_id( ) {
        return icl_object_id( get_option( 'jigoshop_thanks_page_id' ), 'page', true );
    }
    
    /**
     * Filters JigoShop payment link for unpaid - pending orders.
     * 
     * @global type $sitepress
     * @param type $link
     * @return type 
     */
    function get_checkout_payment_url( $link ) {
        global $sitepress;
        return $sitepress->convert_url( $link );
    }
    
    /**
     * Filters JigoShop my account link.
     * 
     */
    function get_myaccount_page_id( ) {
        return get_permalink( icl_object_id( get_option( 'jigoshop_myaccount_page_id' ), 'page', true ) );
    }
    
    /**
     * Filters JigoShop my account edit address link.
     * 
     */
    function get_edit_address_page_id( ) {
        return get_permalink( icl_object_id( get_option( 'jigoshop_edit_address_page_id' ), 'page', true ) );
    }
    
    /**
     * Filters JigoShop view order link.
     * 
     */
    function get_view_order_page_id( ) {
        return get_permalink( icl_object_id( get_option( 'jigoshop_view_order_page_id' ), 'page', true ) );
    }
    
    /**
     * Filters JigoShop my account change password link.
     * 
     */
    function get_change_password_page_id( ) {
        return get_permalink( icl_object_id( get_option( 'jigoshop_change_password_page_id' ), 'page', true ) );
    }
    
    /**
     * Filters JigoShop checkout link.
     * 
     */
    function get_checkout_url( ) {
        return get_permalink( icl_object_id( get_option( 'jigoshop_checkout_page_id' ), 'page', true ) );
    }
    
    /**
     * Filters JigoShop cart link.
     *  
     */
    function get_cart_url( ) {
        return get_permalink( icl_object_id( get_option( 'jigoshop_cart_page_id' ), 'page', true ) );
    }
    
    /**
     * Filters JigoShop params.
     * 
     * @global type $sitepress
     * @global type $post
     * @param type $value
     * @return type 
     */
    function params( $value ) {
        global $sitepress, $post;
        
        if ( $sitepress->get_current_language() !== $sitepress->get_default_language() ) {
            $value[ 'checkout_url' ] = admin_url( 'admin-ajax.php?action=jigoshop-checkout&lang=' . $sitepress->get_current_language() );
            $value[ 'ajax_url' ]     = admin_url( 'admin-ajax.php?lang=' . $sitepress->get_current_language() );
            
            $checkout_page_id            = get_option( 'jigoshop_checkout_page_id' );
            $translated_checkout_page_id = icl_object_id( $checkout_page_id, 'page', false );
            
            if ( $translated_checkout_page_id == $post->ID ) {
                $value[ 'is_checkout' ]                 = 1;
                $_SESSION[ 'wpml_globalcart_language' ] = $sitepress->get_current_language();
            }
        }
        
        return $value;
    }
    
    /**
     * Adds language to the order post type.
     * 
     * Language was stored before in session created on checkout page.
     * See params().
     * 
     * @param type $get_order 
     * @param type $id 
     * @return type
     */
    function order_language( $get_order, $id ) {
        if ( !get_post_meta( $id, 'wpml_language' ) ) {
            $language = isset( $_SESSION[ 'wpml_globalcart_language' ] ) ? $_SESSION[ 'wpml_globalcart_language' ] : ICL_LANGUAGE_CODE;
            update_post_meta( $id, 'wpml_language', $language );
        }
        
        return $get_order;
    }
    
    /**
     * Filters the cart page product title.
     * 
     * @param type $title
     * @param type $_product
     * @return type
     */
    function cart_product_title( $title, $_product ) {
        $product_id = icl_object_id( $_product->id, 'product', false, ICL_LANGUAGE_CODE );
        
        if ( $product_id ) {
            $title = get_the_title( $product_id );
        }
        
        return $title;
    }
    
    /**
     * Filters WPML language switcher.
     * 
     * @global type $post
     * @global type $sitepress
     * @param type $languages
     * @return type 
     */
    function language_selector( $languages ) {
        global $post, $sitepress;
        
        if ( strpos( basename( $_SERVER[ 'REQUEST_URI' ] ), 'post_type' ) !== false || strpos( basename( $_SERVER[ 'REQUEST_URI' ] ), 'shop' ) !== false ) {
            foreach ( $languages as $lang_code => $language ) {
                $languages[ $lang_code ][ 'url' ] = $sitepress->convert_url( get_option( 'home' ) . '/?post_type=product', $language[ 'language_code' ] );
            }
        }
        
        return $languages;
    }
    
    /**
     * Translates payment gateways title and description.
     *
	 * @param type $_available_gateways
     * @return type
     */
	function translate_payment_gateways( $_available_gateways ){
		if( !empty( $_available_gateways ) ){
			foreach( $_available_gateways as $name => $gateway ){
				$_gateway = (object) $gateway;
				
				if ( function_exists( 'icl_translate' ) ) {
					$_gateway->title = icl_translate( 'jigoshop', $gateway->title . '_gateway_title', $gateway->title );
					$_gateway->description = icl_translate( 'jigoshop', $gateway->title . '_gateway_description', $gateway->description );
				}
				
				$_available_gateways[ $name ] = $_gateway;
			}
		}
		
		return $_available_gateways;
	}
	
	/**
     * Localizes AJAX loaded content.
     * 
	 * @global type $sitepress
     * @return type
     */
	function localize_on_ajax(){
		global $sitepress;
		
		$current_language = $sitepress->get_current_language();
		
		$sitepress->switch_lang( $current_language, true );
	}
	
}

?>